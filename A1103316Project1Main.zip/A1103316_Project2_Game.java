import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class A1103316_Project2_Game
{
    // The randomizer which is used for shuffling the deck.
    private static final Random RANDOM = new Random(System.currentTimeMillis());
    // The game consists of 5 rounds of exploration.
    private static final int ROUND = 5;

    // All explorers participate in the game.
    private final ArrayList<A1103316_Project2_Agent> explorers = new ArrayList<>();
    // The deck of cards to be used for the game.
    private final ArrayList<A1103316_Project2_Card> deck = new ArrayList<>();
    // A tomb-like path for exploration.
    private final ArrayList<A1103316_Project2_Card> path = new ArrayList<>();

    private final ArrayList<A1103316_Project2_Agent> survivors = new ArrayList<>();

    private final ArrayList<A1103316_Project2_Agent> wantleave = new ArrayList<>();
    // There are 5 sections (5 rounds) of exploration in the tomb, and one particular artifact is deposited in each section.
    private final ArrayList<A1103316_Project2_Artifact> artifacts = new ArrayList<>();
    // The Hazards that occurred during the game play.
    private final ArrayList<A1103316_Project2_Hazard> occurredHazards = new ArrayList<>();

    private final ArrayList<A1103316_Project2_Agent> winner = new ArrayList<>();

    public A1103316_Project2_Game()
    {
        this.explorers.add(new A1103316_Project2_Agent(0));
        this.explorers.add(new A1103316_Project2_Agent(1));
        this.explorers.add(new A1103316_Project2_Agent(2));
        this.explorers.add(new A1103316_Project2_Agent(3));
        this.explorers.add(new A1103316_Project2_Agent(4));
        this.explorers.add(new A1103316_Project2_Agent(5));
        
        this.setUpCards();
    }
    
    public void runGame()
    {
        for (int round = 0; round < ROUND; round++)
        {
          /********************************* TODO (Checkpoint 1) *********************************
             * TODO 4-1: First, the game data should be initialized at the beginning of each round.
             * Hint 1: All explorers' status should be switched to true.
             * Hint 2: Clear all cards on the path and shuffle them back in the deck.
             * Hint 3: Reset the value of all gemstone cards.
             * Hint 4: Make sure you use shuffleDeck() method to shuffle the deck.
             * Hint 5: You need to print "ROUND X START!" which X represents for the round number (1~5).
             * Notice 1: In this section, you can use doNothing() method as you like to set timeout between any message you would print,
             *           but the format of your output must identically be the same as what the document shows.
             ************************************* End of TODO *************************************/

            /************ START OF YOUR CODE ************/

           System.out.printf("ROUND %d START!\n",round+1);//4-1初始化數據
           this.deck.clear();
           path.clear();
           //artifacts.clear();
           this.occurredHazards.clear();
           setUpCards();
           this.deck.add(this.artifacts.get(round));
           shuffleDeck();
            
    
           for (int i =0; i<deck.size() ; i++) {    
              deck.get(i).resetValue();
           }
           for (int i =0; i<explorers.size() ; i++) {
              explorers.get(i).setInExploring(true);  
           }

           
            /************* END OF YOUR CODE *************/
           
           while (this.isAnyoneStay() )
            {
              /********************************* TODO (Checkpoint 1) *********************************
                 * TODO 4-2: During a round, all explorers explore the path in the ancient tomb and hunt for abundant treasures.
                 * Hint 1: To move forward in our exploration, you need to draw a card from the top of the deck and put it on the end of the path.
                 *         Use share() method of Gemstone object so that the value of the card can be shared by all explorers who stay.
                 * Hint 2: Print out the information of the path.
                 * Hint 3: Print out the information of all explorers in sequence. If the explorer stays in the tomb, print "Explorer X has Y gem(s).",
                 *         otherwise, print "Explorer X left." which X and Y represent for their number and the quantity of collected gems.
                 * Hint 4: After "----- STAY or LEAVE -----" is printed, all explorers who stay have to make their decision about staying or leaving.
                 *         For this purpose, you can use act() method of Agent object.
                 * Hint 5: Print "Everyone keeps exploring." if there is no explorer choose to leave,
                 *         else print "Explorer X wants to leave." for each explorer who chose to leave, which X represents for their number.
                 * Hint 6: For those who chose to leave the tomb, should share the value of all the cards on the path while each one works independently.
                 *         If the path is [<3/11>, <1/9>, <5/13>], for instance, there are 3 explorers who chose to leave,
                 *         then the path will become [<0/11>, <1/9>, <2/13>] after they leave.
                 * Notice 1: In this checkpoint, we'll only implement the mechanism of gemstone, i.e., artifact and hazard are not considered now.
                 * Notice 2: In this checkpoint, a round will end when either everyone leaves the tomb or the length of the path reaches 10.
                 *           Note that when the 10th card shows, the game will still ask about staying or leaving, no special handling required.
                 * Notice 3: The act() method of Agent requires an Environment object as its parameter, which indicates that agent can act upon the environment.
                 *           Note that the variable $environment was already declared for you, all you need to do is pass it into the act() method.
                 *           All explorers should act upon the same environment, so do not declare another Environment object or it may cause some error.
                 * Notice 4: In this section, you can use doNothing() method as you like to set timeout between any message you would print,
                 *           but the format of your output must identically be the same as what the document shows.
                 ************************************* End of TODO *************************************/

                /************ START OF YOUR CODE ************/
                int tp0=0,tp1=0,tp2=0,tp3=0,tp4=0;//紀錄災厄卡
                for (int times =0 ; times<this.deck.size() ; times++) {
                    System.out.println();
                    this.survivors.clear();
                    this.wantleave.clear();
                    getStayExplorers();//回傳玩的人 也就是surviver
                    this.path.add(this.deck.get(times));
                   
                    if (this.path.get(times) instanceof A1103316_Project2_Hazard){
                      if (this.path.get(times).getType() == 0) {
                          tp0++;
                      }
                      if (this.path.get(times).getType() == 1) {
                         tp1++;
                      }
                      if (this.path.get(times).getType() == 2) {
                          tp2++;
                      }
                      if (this.path.get(times).getType() == 3) {
                          tp3++;
                      }  
                      if (this.path.get(times).getType() == 4) {
                          tp4++;
                      }
                    }
                  
                    if (this.path.get(times) instanceof A1103316_Project2_Gemstone) {
                      this.path.get(times).share(survivors);
                    }

                    
                                                                                            
                    for (int i=-1 ; i<=times ;i++) {
                        if (i==-1) {
                           System.out.printf("[");   
                        }else if (i !=times) {
                           System.out.printf("%s,",this.deck.get(i).toString());
                        }else if (i ==times) {   
                           System.out.printf("%s]",this.deck.get(i).toString());
                        }   
                    }//寶石卡的樣式
                    if(this.path.contains(this.artifacts.get(round)) == true){
                      System.out.print("神器卡在通道");
                    }
                   
                    System.out.println();
                    for (int n =0; n<this.explorers.size() ; n++) {
                        if (this.explorers.get(n).isInExploring() == true) {
                            System.out.printf("%s has %d gem(s).\n",this.explorers.get(n),this.explorers.get(n).getCollectedGems());
                        } else {
                            System.out.printf("%s left.\n",this.explorers.get(n));
                        }
                    } 
                  
                /************* END OF YOUR CODE *************/

                System.out.println("----- STAY or LEAVE -----");

                A1103316_Project2_Environment environment = this.createEnvironment();

                /************ START OF YOUR CODE ************/                
                  
                 if (tp0 == 2) {
                     this.occurredHazards.add(new A1103316_Project2_Hazard(0));
                     this.deck.remove(this.path.get(times));
                     for (A1103316_Project2_Agent survivor : this.survivors)                     
                          survivor.flee();                    
                     System.out.printf("%s hazard occurs, all explorers attempt to flee!",this.occurredHazards.get(0).name());
                     break;
                 }
                 if (tp1 == 2) {
                     this.occurredHazards.add(new A1103316_Project2_Hazard(1));
                     this.deck.remove(this.path.get(times));
                     for (A1103316_Project2_Agent survivor : this.survivors)                     
                          survivor.flee();                    
                     System.out.printf("%s hazard occurs, all explorers attempt to flee!",this.occurredHazards.get(0).name());
                     break;
                 }
                 if (tp2 == 2) {
                     this.occurredHazards.add(new A1103316_Project2_Hazard(2));
                     this.deck.remove(this.path.get(times));
                     for (A1103316_Project2_Agent survivor : this.survivors)                     
                          survivor.flee();                    
                     System.out.printf("%s hazard occurs, all explorers attempt to flee!",this.occurredHazards.get(0).name());
                     break;
                 } 
                 if (tp3 == 2) {
                     this.occurredHazards.add(new A1103316_Project2_Hazard(3));
                     this.deck.remove(this.path.get(times));
                     for (A1103316_Project2_Agent survivor : this.survivors)                     
                          survivor.flee();                    
                     System.out.printf("%s hazard occurs, all explorers attempt to flee!",this.occurredHazards.get(0).name());
                     break;
                 }
                 if (tp4 == 2) {
                     this.occurredHazards.add(new A1103316_Project2_Hazard(4));
                     this.deck.remove(this.path.get(times));
                     for (A1103316_Project2_Agent survivor : this.survivors)                     
                          survivor.flee();                    
                     System.out.printf("%s hazard occurs, all explorers attempt to flee!",this.occurredHazards.get(0).name());
                     break;
                 } 
                 int c=0;//數有沒有人要走
                 for (int i =0; i<this.explorers.size() ; i++) {
                      if (this.explorers.get(i).isInExploring() == true) {
                          this.explorers.get(i).act(environment);
                           if (this.explorers.get(i).isInExploring() == false) {
                               System.out.printf("%s wants to leave.  \n",this.explorers.get(i));
                               c++;
                               this.wantleave.add(this.explorers.get(i));
                           }
                           if (c==0) {
                               System.out.print("Everyone keeps exploring.\n");
                               break;
                           }
                       }
                  }//for的
                

                 for(int i = 0; i <= times ; i++) {
                     if (this.path.get(i) instanceof A1103316_Project2_Artifact) {
                          if (wantleave.size() == 1 && this.artifacts.get(round).isInTomb()==true) {
                              wantleave.get(0).getOwnedArtifacts().add(this.artifacts.get(round));
                              this.artifacts.get(round).setInTomb(false);//把這張神器卡脫離
                              //this.path.get(i).share(wantleave);
                          }
                     }
                     if (this.path.get(i) instanceof A1103316_Project2_Treasure) {
                         this.path.get(i).share(wantleave); 
                     }  
                 }
                      
                  /************* END OF YOUR CODE *************/
                    
                     
                    if (this.isAnyoneStay()==false) {
                       break;
                    }

                  
                }//印牌的for    
            } //while的    
                /************* END OF YOUR CODE *************/
            
            /********************************* TODO (Checkpoint 1) *********************************
             * TODO 4-3: At the end of a round, all explorers finish their exploration and return to the camp with treasure.
             ************************************* End of TODO *************************************/

            /************ START OF YOUR CODE ************/
            System.out.println();
            System.out.printf("ROUND %d END!\n",round+1);
            this.deck.remove(this.artifacts.get(round));
            System.out.println();
            for (int i =0; i<explorers.size() ; i++) {
                  explorers.get(i).storeGemsIntoTent();
                  System.out.printf("%d 神器%d\n",explorers.get(i).getGemsInsideTent(),explorers.get(i).getOwnedArtifacts().size());
                  
            }
            /************* END OF YOUR CODE *************/
        }//for

        System.out.println("GAME OVER!");
        System.out.println();
        System.out.println("----- Final result -----");

        for (A1103316_Project2_Agent explorer : this.explorers)
            System.out.println(explorer + ": " + explorer.totalValue());

        System.out.println();
        System.out.println("Winner: " + this.getWinners());  
    }//rungame

    private void setUpCards()
    {
        this.deck.add(new A1103316_Project2_Hazard(0));
        this.deck.add(new A1103316_Project2_Hazard(0));
        this.deck.add(new A1103316_Project2_Hazard(0));
        this.deck.add(new A1103316_Project2_Hazard(1));
        this.deck.add(new A1103316_Project2_Hazard(1));
        this.deck.add(new A1103316_Project2_Hazard(1));
        this.deck.add(new A1103316_Project2_Hazard(2));
        this.deck.add(new A1103316_Project2_Hazard(2));
        this.deck.add(new A1103316_Project2_Hazard(2));
        this.deck.add(new A1103316_Project2_Hazard(3));
        this.deck.add(new A1103316_Project2_Hazard(3));
        this.deck.add(new A1103316_Project2_Hazard(3));
        this.deck.add(new A1103316_Project2_Hazard(4));
        this.deck.add(new A1103316_Project2_Hazard(4));
        this.deck.add(new A1103316_Project2_Hazard(4));
        
        this.deck.add(new A1103316_Project2_Gemstone(10, 1));
        this.deck.add(new A1103316_Project2_Gemstone(11, 2));
        this.deck.add(new A1103316_Project2_Gemstone(12, 3));
        this.deck.add(new A1103316_Project2_Gemstone(13, 4));
        this.deck.add(new A1103316_Project2_Gemstone(14, 5));
        this.deck.add(new A1103316_Project2_Gemstone(14, 5));
        this.deck.add(new A1103316_Project2_Gemstone(15, 7));
        this.deck.add(new A1103316_Project2_Gemstone(15, 7));
        this.deck.add(new A1103316_Project2_Gemstone(16, 9));
        this.deck.add(new A1103316_Project2_Gemstone(17, 11));
        this.deck.add(new A1103316_Project2_Gemstone(17, 11));
        this.deck.add(new A1103316_Project2_Gemstone(18, 13));
        this.deck.add(new A1103316_Project2_Gemstone(19, 14));
        this.deck.add(new A1103316_Project2_Gemstone(20, 15));
        this.deck.add(new A1103316_Project2_Gemstone(21, 17));
        
        this.artifacts.add(new A1103316_Project2_Artifact(0, 5));
        this.artifacts.add(new A1103316_Project2_Artifact(1, 7));
        this.artifacts.add(new A1103316_Project2_Artifact(2, 8));
        this.artifacts.add(new A1103316_Project2_Artifact(3, 10));
        this.artifacts.add(new A1103316_Project2_Artifact(4, 12));
    }

    private void shuffleDeck()
    {
        Collections.shuffle(this.deck, RANDOM);
    }

    private ArrayList<A1103316_Project2_Agent> getStayExplorers()
    {
      
        /********************************* TODO (Checkpoint 1) *********************************
         * TODO 3-1: Get all explorers who stay in the tomb.
         * Hint 1: You can check each explorer's status.
         ************************************* End of TODO *************************************/

        /************ START OF YOUR CODE ************/

       for(int i = 0 ; i<explorers.size() ; i++) {
          if (explorers.get(i).isInExploring() == true) {
              this.survivors.add(this.explorers.get(i));
          }
       }
       return survivors;
      
        /************* END OF YOUR CODE *************/
    }

    private boolean isAnyoneStay()
    {
        /********************************* TODO (Checkpoint 1) *********************************
         * TODO 3-2: Check if there is anyone who stays in the tomb.
         * Hint 1: Return true if at least one explorer is in exploring.
         ************************************* End of TODO *************************************/

        /************ START OF YOUR CODE ************/
        boolean k = false;
        for(int i = 0 ; i<this.explorers.size() ; i++) {
            if (this.explorers.get(i).isInExploring() != false) {
                k = true;
                break; 
            }
            else if (this.explorers.get(i).isInExploring() == false) {
                continue;
            }    
        }
        return k;
        /************* END OF YOUR CODE *************/
    }

    private ArrayList<A1103316_Project2_Agent> getWinners()
    {
        /********************************* TODO (Checkpoint 2) *********************************
         * TODO 5-3: The winners will be the explorers who hold the highest value of treasure.
         * Hint 1: You can use totalValue() method of Agent object to check the total value that they hold.
         * Notice 1: There might be multiple winners if more than one explorers equivalently hold the highest value.
         ************************************* End of TODO *************************************/

        /************ START OF YOUR CODE ************/
        int max = this.explorers.get(0).getGemsInsideTent();
        for (int num =1 ; num<explorers.size(); num++) {
          if (this.explorers.get(num).totalValue() > max){
              max =this.explorers.get(num).totalValue();
          }
        }
        //System.out.printf("%d",max);       
        
        for (int i =0; i<this.explorers.size() ; i++) {          
            if (this.explorers.get(i).totalValue() == max ) {
                winner.add(this.explorers.get(i));
                System.out.printf("%d\n",this.explorers.get(i).totalValue());
            }
            else if (this.explorers.get(i).totalValue() < max ) {
            }            
        }
             
        return this.winner;
        /************* END OF YOUR CODE *************/
    }
  
    private A1103316_Project2_Environment createEnvironment()
    {
        A1103316_Project2_Environment environment = new A1103316_Project2_Environment();

        environment.setDefaultDecisionProbability(0.65);

        return environment;
    }

    private static void doNothing(long millisecond)
    {
        if (millisecond > 2000) 
            throw new IllegalArgumentException("timeout value is over 2000");

        try
        {
            Thread.sleep(millisecond);
        }
        catch (InterruptedException e)
        {
            throw new IllegalStateException("unexpected interruption");
        }

    }
}
