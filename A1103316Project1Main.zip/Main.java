public class Main {
  public static void main(String[] args) {
    A1103316_Project2_Game game = new A1103316_Project2_Game();
    game.runGame();
  }
}
