import java.util.ArrayList;

public abstract class A1103316_Project2_Card
{
    // Type of this card.
    private final int type;

    public A1103316_Project2_Card(int type)
    {
        this.type = type;
    }
    
    public abstract String name();

    public abstract void resetValue();

    public abstract void share(ArrayList<A1103316_Project2_Agent> receivers);
  
    public int getType()
    {
        return this.type;
    }
}
